import { pool } from '../dist-api/db.js';
import { encryptToken } from '../dist-api/security.js';
import { SocialProviderRegistry } from '../dist-api/social.provider.js';

const workspaceId = '4386cbf8-47bf-41fe-a925-0549bced08f2';
const newBotToken = '8818622380:AAG2DwTkCGKT4J9ai2VDSEdNWZp81ojIeTQ';

async function main() {
  console.log('--- Validating & Updating Telegram Bot Token ---');
  
  const acc = (await pool.query(
    "SELECT * FROM social_accounts WHERE workspace_id = $1 AND lower(platform) = 'telegram'",
    [workspaceId]
  )).rows[0];

  if (!acc) {
    throw new Error('Telegram account not found in workspace ' + workspaceId);
  }

  console.log('Existing Account Info:', {
    id: acc.id,
    name: acc.name,
    chatId: acc.provider_id,
    state: acc.state,
  });

  const chatId = acc.provider_id;
  const provider = SocialProviderRegistry.getProvider('telegram');
  const valResult = await provider.validateConnection({
    botToken: newBotToken,
    chatId: chatId,
  });

  console.log('Validation Result with Telegram API:', valResult);

  if (!valResult.valid) {
    console.error('Validation failed:', valResult.details?.error);
    process.exit(1);
  }

  const encryptedToken = encryptToken(newBotToken, workspaceId);

  await pool.query(
    "UPDATE social_accounts SET name = $1, state = 'CONNECTED', last_sync = NOW() WHERE id = $2",
    [valResult.name, acc.id]
  );

  await pool.query(
    "INSERT INTO social_account_tokens(account_id, ciphertext, expires_at) VALUES($1, $2, null) ON CONFLICT (account_id) DO UPDATE SET ciphertext = EXCLUDED.ciphertext, expires_at = null",
    [acc.id, encryptedToken]
  );

  console.log(' Successfully updated Telegram Bot Token in database!');
  process.exit(0);
}

main().catch(err => {
  console.error('Error:', err);
  process.exit(1);
});
