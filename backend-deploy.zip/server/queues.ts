import { pool, type DB } from './db.js';
import { queueBackend } from './queue-backend.js';
import { PostgresQueue } from './postgres-queue.js';

const legacy = queueBackend() === 'bullmq';
const bull = legacy ? await import('bullmq') : null;
const RedisClass = legacy ? (await import('ioredis')).Redis : null;
export const redis = RedisClass ? new RedisClass(process.env.REDIS_URL || 'redis://127.0.0.1:6379', {
  maxRetriesPerRequest: null,
}) : null as any;
export const postgresQueue = new PostgresQueue(pool);
export const queueNames = ['content-generation','pdf-processing','video-rendering','social-publishing','analytics-sync','notification'] as const;
type JobOptions = { jobId?: string; delay?: number; attempts?: number; backoff?: { type: string; delay: number }; [key: string]: any };

async function validateTenant(queue: string, data: any, db: DB) {
  let row: any;
  if (queue === 'social-publishing') {
    row = (await db.query('SELECT workspace_id FROM scheduled_posts WHERE id=$1',[data.id])).rows[0];
    if (data.workspaceId && row?.workspace_id !== data.workspaceId) throw new Error('Queue tenant mismatch');
  } else {
    const mapping: Record<string,[string,string]> = {
      'pdf-processing': ['documents','documentId'],
      'content-generation': ['ai_generations','generationId'],
      'batch-processing': ['batch_jobs','batchId'],
      'knowledge-automation': ['documents','documentId'],
    };
    const entry = mapping[queue];
    if (!entry || !data.workspaceId) throw new Error('Unsupported queue or missing tenant');
    row = (await db.query(`SELECT workspace_id FROM ${entry[0]} WHERE id=$1 AND workspace_id=$2`,[data[entry[1]],data.workspaceId])).rows[0];
    if (queue === 'content-generation' && row) {
      const document = (await db.query('SELECT id FROM documents WHERE id=$1 AND workspace_id=$2',[data.documentId,data.workspaceId])).rows[0];
      if (!document) throw new Error('Queue document tenant mismatch');
    }
  }
  if (!row?.workspace_id) throw new Error('Queue source record missing or outside tenant');
  return row.workspace_id as string;
}

export function createQueue(name: string, defaults: { defaultJobOptions?: JobOptions } = {}) {
  if (bull) {
    const q = new bull.Queue(name,{connection:redis,defaultJobOptions:defaults.defaultJobOptions as any});
    return {
      name: q.name,
      add: (jobName: string,data: any,opts?: JobOptions,_db?: DB) => q.add(jobName,data,opts as any),
      getJob: (id: string,_workspaceId?: string,_db?: DB) => q.getJob(id),
      close: () => q.close(),
      options: { connection:redis, ...defaults },
    };
  }
  return {
    name,
    async add(jobName: string,data: any,opts: JobOptions = {},db: DB = pool) {
      const workspaceId = await validateTenant(name,data,db);
      const options = { ...defaults.defaultJobOptions,...opts };
      const key = options.jobId || data.batchId || data.generationId || data.documentId || data.id;
      if (!key) throw new Error('A stable queue job identifier is required');
      return postgresQueue.enqueue(name,jobName,{...data,workspaceId},{
        workspaceId,key,attempts:options.attempts,backoff:options.backoff?.delay,
        runAt:new Date(Date.now()+(options.delay || 0)),
      },db);
    },
    async getJob(id: string,workspaceId?: string,db: DB = pool) {
      if (!workspaceId) throw new Error('Queue lookup requires workspaceId');
      const row = (await db.query('SELECT * FROM queue_jobs WHERE queue=$1 AND scope=$2 AND dedupe_key=$3',[name,workspaceId,id])).rows[0];
      if (!row) return undefined;
      return {
        getState: async () => row.state,
        remove: async () => {
          const changed = await db.query(`UPDATE queue_jobs SET dedupe_key=dedupe_key||':archived:'||id::text,updated_at=now()
            WHERE id=$1 AND workspace_id=$2 AND state IN ('failed','completed','cancelled')`,[row.id,workspaceId]);
          if (!changed.rowCount) throw new Error('Active or uncertain job cannot be removed');
        },
      };
    },
    close: async () => {},
    options: defaults,
  };
}
export const publishingQueue = createQueue('social-publishing', {
  defaultJobOptions: {
    attempts:5,backoff:{type:'exponential',delay:60000},
    removeOnComplete:{age:7*86400},removeOnFail:{age:30*86400},
  },
});
