import {
  Body,
  Controller,
  Post,
  Req,
  ServiceUnavailableException,
  BadRequestException,
  NotFoundException,
} from "@nestjs/common";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { pool, audit, transaction } from "./db.js";
import {
  WorkspaceRequired,
  assertPermission,
  type AuthedRequest,
} from "./security.js";
import { platformSchema } from "./content.controller.js";
import { getLLMProvider } from "./ai/llm.service.js";
import { assertWorkspaceActive } from "./billing/entitlement.service.js";

const brief = z.object({
  topic: z.string().trim().min(5).max(15000),
  tone: z.string().max(50),
  goal: z.string().max(80),
  platforms: z.array(platformSchema).min(1).max(5),
});

const captionsOutputSchema = z.object({
  title: z.string().min(1).max(160),
  variants: z.record(platformSchema, z.string().trim().min(1).max(5000)),
});

function extractContextualHashtags(title: string, content: string, existingHashtags?: string): string {
  const combined = `${title} ${content}`.toLowerCase();
  const words = combined.match(/\b[a-z]{4,}\b/g) || [];
  const stopWords = new Set(["this", "that", "with", "from", "your", "have", "more", "will", "been", "only", "were", "into", "their", "about", "which", "there", "brand", "brands", "slide", "page", "write", "claims", "evidence", "approved", "material", "workspace", "palak", "user"]);
  const keywords = words.filter(w => !stopWords.has(w));
  const uniqueKeywords = [...new Set(keywords)].slice(0, 5);
  const dynamicTags = uniqueKeywords.map(k => `#${k.charAt(0).toUpperCase() + k.slice(1)}`);
  
  const defaultPopular = ["#TechInnovation", "#SoftwareGrowth", "#Productivity", "#Scale"];
  const userTags = existingHashtags ? existingHashtags.split(/\s+/).filter(t => t.startsWith('#')) : [];
  const allTags = [...new Set([...dynamicTags, ...userTags, ...defaultPopular])].slice(0, 7);
  return allTags.join(' ');
}

function generateFallbackCaptions(
  topic: string,
  tone = "Professional",
  goal = "Engagement",
  platforms: string[] = ["LinkedIn"],
  brandData?: Record<string, any>
) {
  let cleanContent = topic.trim();
  let cleanTitle = "";

  if (cleanContent.startsWith("{")) {
    try {
      const parsed = JSON.parse(cleanContent);
      if(parsed.imagePrompt){
        cleanTitle=String(parsed.imagePrompt).replace(/^(create|generate|draw)\s+(an?\s+)?(image|poster|picture)\s+(of\s+)?/i,'').slice(0,100);
        cleanContent=parsed.captionAngle==='Conversation'?'What stands out to you about '+cleanTitle+'?':parsed.captionAngle==='Benefit'?'A fresh perspective on '+cleanTitle+'. Save this idea for your next creative project.':'A moment inspired by '+cleanTitle+'. Small details can tell a memorable story.';
      }
      if (parsed.knowledge) {
        cleanTitle = String(parsed.knowledge).replace(/^"|"$/g, "").slice(0, 100).trim();
        cleanContent = (parsed.evidence?.[0]?.excerpt || cleanTitle) + "\n\n" + (cleanTitle !== parsed.evidence?.[0]?.excerpt ? cleanTitle : "");
      }
    } catch {}
  }

  const contentMatch = cleanContent.match(/Internal title:\s*(.*?)\nContent:\s*([\s\S]*)/i);
  if (contentMatch) {
    cleanTitle = contentMatch[1].trim();
    cleanContent = contentMatch[2].trim();
  }

  if (!cleanTitle) {
    const firstLine = cleanContent.split("\n")[0] || "Innovation Update";
    cleanTitle = firstLine.replace(/^[#*\-•\s]+/, "").slice(0, 80).trim();
    if (cleanTitle.length > 50 && cleanTitle.includes("...")) {
      cleanTitle = cleanTitle.split("...")[0].trim();
    }
  }

  const cta = typeof brandData?.cta === "string" ? brandData.cta.trim() : "";
  const dynamicHashtags = extractContextualHashtags(cleanTitle, cleanContent, typeof brandData?.hashtags === "string" ? brandData.hashtags : undefined);

  const engagementQuestions = [
    "How does this impact your daily workflow? Share your thoughts below! 👇",
    "What’s your take on this milestone? Let’s connect in the comments. 💬",
    "Where is your team seeing the biggest performance gains this quarter?",
    "Drop your feedback or questions below—we’d love to hear from you! 🚀"
  ];
  const qIdx = Math.abs(cleanTitle.length) % engagementQuestions.length;
  const question = goal.toLowerCase().includes("engage") ? engagementQuestions[qIdx] : "";

  const variants: Record<string, string> = {};

  for (const p of platforms) {
    switch (p) {
      case "Telegram": {
        const parts = [
          `📢 **${cleanTitle}**`,
          `\n${cleanContent}`
        ];
        if (question) parts.push(`\n💬 ${question}`);
        if (cta) parts.push(`\n👉 ${cta}`);
        parts.push(`\n${dynamicHashtags}`);
        variants["Telegram"] = parts.join("\n").slice(0, 4000);
        break;
      }
      case "X": {
        let xText = `⚡ ${cleanTitle}\n\n${cleanContent}`;
        if (xText.length > 210) {
          xText = xText.slice(0, 207) + "...";
        }
        const topTags = dynamicHashtags.split(" ").slice(0, 3).join(" ");
        variants["X"] = `${xText}\n\n${topTags}`.slice(0, 280);
        break;
      }
      case "Instagram": {
        const parts = [
          `✨ **${cleanTitle}**`,
          `\n${cleanContent}`
        ];
        if (question) parts.push(`\n${question}`);
        if (cta) parts.push(`\n🔗 Link in bio to learn more.`);
        parts.push(`\n.\n.\n${dynamicHashtags}`);
        variants["Instagram"] = parts.join("\n").slice(0, 2200);
        break;
      }
      case "YouTube": {
        const parts = [cleanTitle, `\n${cleanContent}`];
        if (cta) parts.push(`\n\n${cta}`);
        parts.push(`\n${dynamicHashtags}`);
        variants["YouTube"] = parts.join("\n").slice(0, 5000);
        break;
      }
      case "LinkedIn": {
        const parts = [
          `💡 **${cleanTitle}**`,
          `\n${cleanContent}`,
          `\nConsistency and speed are everything in modern business. We’re doubling down on efficiency to help teams achieve higher output with less friction.`
        ];
        if (question) parts.push(`\n${question}`);
        if (cta) parts.push(`\n\n${cta}`);
        parts.push(`\n${dynamicHashtags}`);
        variants["LinkedIn"] = parts.join("\n").slice(0, 3000);
        break;
      }
      case "Facebook":
      default: {
        const parts = [
          `🚀 **${cleanTitle}**`,
          `\n${cleanContent}`
        ];
        if (question) parts.push(`\n${question}`);
        if (cta) parts.push(`\n\n${cta}`);
        parts.push(`\n${dynamicHashtags}`);
        variants[p] = parts.join("\n").slice(0, 5000);
        break;
      }
    }
  }

  return {
    title: cleanTitle.slice(0, 160) || "Social Update",
    variants,
  };
}

export async function generateCaptions(
  topic: string,
  tone = "Professional",
  goal = "Engagement",
  platforms: string[] = ["LinkedIn"],
  brandData?: Record<string, any>
) {
  try {
    const provider = getLLMProvider();
    if (await provider.validateConfiguration()) {
      const sanitizedBrand = { ...(brandData || {}) };
      if (typeof sanitizedBrand.name === "string" && (/('s|’s)?\s*workspace/i.test(sanitizedBrand.name) || /workspace/i.test(sanitizedBrand.name) || /palak/i.test(sanitizedBrand.name))) {
        delete sanitizedBrand.name;
      }

      const promptMessages = [
        {
          role: "system" as const,
          content:
            'You are an elite, modern social media copywriter. Generate compelling, viral, high-converting social media posts with relevant emojis, hooks, structured line breaks, and 3-6 targeted hashtags. Return only JSON matching schema: {"title":"catchy title","variants":{"LinkedIn":"caption",...}}. Include exactly the requested platforms. Tone: adapt to the requested tone (e.g. Professional, Bold, Conversational). CRITICAL PRIVACY RULE: NEVER include personal user names (e.g. "Palak"), personal creator names, or internal account/workspace identifiers (e.g. never write "workspace", "Palak\'s workspace", or "my workspace"). Speak authoritatively as the company or brand. For LinkedIn: professional, structured, insightful hook with clean line spacing. For Instagram: engaging, visual-first, captivating emojis, and hashtags at bottom. For X/Twitter: punchy, under 280 characters, strong hook with 2-3 hashtags. For Telegram: friendly, community-first update with bold headlines and emojis. For YouTube: informative description with call to action. Produce distinct variants tailored to each platform.',
        },
        { role: "user" as const, content: JSON.stringify({ brief: { topic, tone, goal, platforms }, brand: sanitizedBrand }) },
      ];

      const result = await provider.generateStructured({
        messages: promptMessages,
        schema: captionsOutputSchema,
        schemaName: "SocialCaptions",
      });

      const variantsMap = result.data.variants as Record<string, string>;
      if (!platforms.some(p => !variantsMap[p]?.trim())) {
        const title = result.data.title || "Social Post";
        const enhancedVariants: Record<string, string> = {};
        for (const p of platforms) {
          let text = variantsMap[p] || "";
          if (!text.includes("#")) {
            const tags = extractContextualHashtags(title, text, sanitizedBrand?.hashtags);
            text = `${text.trim()}\n\n${tags}`;
          }
          enhancedVariants[p] = text;
        }
        return {
          title,
          variants: enhancedVariants,
        };
      }
    }
  } catch (err: any) {
    console.warn(`[AI Captions] LLM providers failed (${err?.message || err}). Falling back to rule-based adaptation.`);
  }

  return generateFallbackCaptions(topic, tone, goal, platforms, brandData);
}

@WorkspaceRequired()
@Controller("ai")
export class AIController {
  @Post('image-captions') async imageCaptions(@Req() r:AuthedRequest,@Body() input:unknown){
    assertPermission(r.workspace.role,'edit');
    const v=z.object({assetId:z.string().uuid(),platform:platformSchema.default('Instagram'),prompt:z.string().trim().max(15000).optional()}).parse(input);
    return generateImageCaptions(r.workspace.id,r.user.id,v.assetId,v.platform,v.prompt);
  }
  @Post("captions") async captions(
    @Req() r: AuthedRequest,
    @Body() input: unknown,
  ) {
    assertPermission(r.workspace.role, "edit");
    await assertWorkspaceActive(r.workspace.id, "AI generation");
    const v = brief.parse(input);
    if (new Set(v.platforms).size !== v.platforms.length)
      throw new BadRequestException("Choose each platform once.");

    const brand = (
      await pool.query("SELECT data FROM brand_kits WHERE workspace_id=$1", [
        r.workspace.id,
      ])
    ).rows[0]?.data || {};

    const output = await generateCaptions(v.topic, v.tone, v.goal, v.platforms, brand);

    return transaction(async (db) => {
      const id = randomUUID();
      await db.query(
        `INSERT INTO ai_generations(id, workspace_id, actor_id, provider, input, output)
         VALUES($1, $2, $3, $4, $5, $6)`,
        [
          id,
          r.workspace.id,
          r.user.id,
          process.env.LLM_PROVIDER || "openai-compatible",
          JSON.stringify(v),
          JSON.stringify(output),
        ],
      );

      await audit(
        db,
        r.workspace.id,
        r.user.id,
        "generated captions",
        "ai_generation",
        id,
        output.title,
      );

      return output;
    });
  }
}

/** Reuse the caption provider after an owned image exists; no image-recognition claims. */
export async function generateImageCaptions(workspaceId:string,userId:string,assetId:string,platform:string,prompt?:string){
  await assertWorkspaceActive(workspaceId,'image captions');
  const asset=(await pool.query("SELECT metadata FROM media_assets WHERE id=$1 AND workspace_id=$2 AND deleted_at IS NULL AND status='COMPLETED'",[assetId,workspaceId])).rows[0];
  if(!asset)throw new NotFoundException('Image not found in this workspace.');
  const imagePrompt=String(asset.metadata?.prompt||prompt||'').trim();
  if(imagePrompt.length<5)throw new BadRequestException('An image prompt is required for relevant captions.');
  const brand=(await pool.query('SELECT data FROM brand_kits WHERE workspace_id=$1',[workspaceId])).rows[0]?.data||{};
  const options=[];
  for(const angle of ['Story','Benefit','Conversation']){
    const brief=JSON.stringify({imagePrompt,captionAngle:angle,instructions:"Write a natural prompt-inspired caption with topic-specific hashtags. Never repeat rendering instructions or claim image recognition. Use a distinct opening and structure."});
    const result=await generateCaptions(brief,brand.tone||'Professional',angle==='Conversation'?'Ask a relevant question':angle==='Benefit'?'Explain one practical benefit':'Tell a short engaging story',[platform],brand);
    const caption=result.variants[platform];
    options.push({label:angle,caption,hashtags:Array.from(new Set(caption.match(/#[\p{L}\p{N}_]+/gu)||[]))});
  }
  await pool.query('INSERT INTO ai_generations(id,workspace_id,actor_id,provider,input,output) VALUES($1,$2,$3,$4,$5,$6)',[randomUUID(),workspaceId,userId,process.env.LLM_PROVIDER||'openai-compatible',JSON.stringify({assetId,imagePrompt,platform,kind:'image_captions'}),JSON.stringify({options})]);
  return {assetId,platform,options};
}
