export class StubOcrProvider {
    isAvailable() {
        return process.env.OCR_ENABLED === "true";
    }
    async extract(input) {
        if (!this.isAvailable()) {
            throw new Error("OCR provider is not currently configured or enabled.");
        }
        return {
            text: "",
            confidence: 0,
            provider: process.env.OCR_PROVIDER || "none",
        };
    }
}
export class TesseractOcrProvider {
    isAvailable() {
        return true;
    }
    async extract(input) {
        try {
            // @ts-ignore
            const { createWorker } = await import("tesseract.js");
            const worker = await createWorker(process.env.OCR_LANGUAGES || "eng");
            try {
                const ret = await worker.recognize(input.buffer);
                return {
                    text: ret.data.text || "",
                    confidence: (ret.data.confidence ?? 0) / 100,
                    provider: "tesseract",
                };
            }
            finally {
                await worker.terminate().catch(() => { });
            }
        }
        catch (err) {
            console.warn("[OCR] Tesseract extraction failed:", err?.message || err);
            return { text: "", confidence: 0, provider: "tesseract-failed" };
        }
    }
    async extractFromPDF(pdfBuffer, maxOcrPages = 8, totalPages) {
        const pageTexts = new Map();
        try {
            // @ts-ignore
            const { PDFParse } = await import("pdf-parse");
            // @ts-ignore
            const { createWorker } = await import("tesseract.js");
            const parser = new PDFParse({ data: pdfBuffer });
            const worker = await createWorker("eng");
            try {
                let total = totalPages ?? 0;
                if (total <= 0) {
                    const info = await parser.getText().catch(() => ({ total: 1 }));
                    total = Number(info?.total) || 1;
                }
                // Evenly sample pages across the entire document
                const pagesToExtract = [];
                if (total <= maxOcrPages) {
                    for (let i = 1; i <= total; i++)
                        pagesToExtract.push(i);
                }
                else {
                    const step = (total - 1) / (maxOcrPages - 1);
                    const set = new Set();
                    for (let i = 0; i < maxOcrPages; i++) {
                        const p = Math.min(total, Math.max(1, Math.round(1 + i * step)));
                        if (!set.has(p)) {
                            set.add(p);
                            pagesToExtract.push(p);
                        }
                    }
                }
                console.log(`[OCR] Evenly sampling ${pagesToExtract.length} pages across ${total} total pages:`, pagesToExtract);
                const imgs = await parser.getImage({ partial: pagesToExtract });
                const rawPages = imgs?.pages || [];
                for (let idx = 0; idx < rawPages.length; idx++) {
                    const pageObj = rawPages[idx];
                    const imgData = pageObj?.images?.[0]?.data;
                    const pageNum = pagesToExtract[idx] || pageObj?.num || idx + 1;
                    if (imgData) {
                        const ret = await worker.recognize(Buffer.from(imgData));
                        const text = ret.data.text || "";
                        if (text.trim().length > 0) {
                            pageTexts.set(pageNum, text);
                        }
                    }
                }
            }
            finally {
                await worker.terminate().catch(() => { });
                await parser.destroy().catch(() => { });
            }
        }
        catch (err) {
            console.warn("[OCR] Batch PDF OCR failed:", err?.message || err);
        }
        return pageTexts;
    }
}
// Scanned PDF Heuristic: Average text density < 20 clean characters per page
export function detectScannedPDF(pages) {
    if (!pages || pages.length === 0)
        return true;
    const totalChars = pages.reduce((sum, p) => sum + (p.cleanText?.length || 0), 0);
    const avgCharsPerPage = totalChars / pages.length;
    return avgCharsPerPage < 20;
}
