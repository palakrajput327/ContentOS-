import process from "node:process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (typeof process.loadEnvFile === "function") {
  process.loadEnvFile(path.resolve(__dirname, "../.env"));
}

const { pool } = await import("../dist-api/db.js");

async function main() {
  const wid = "4386cbf8-47bf-41fe-a925-0549bced08f2"; // Palak Gemini's workspace

  const accs = await pool.query("SELECT id, platform, name, state FROM social_accounts WHERE workspace_id = $1", [wid]);
  console.log("social_accounts:", JSON.stringify(accs.rows, null, 2));

  const posts = await pool.query("SELECT id, title, platforms, status, created_at, scheduled_at FROM content WHERE workspace_id = $1 ORDER BY created_at DESC LIMIT 10", [wid]);
  console.log("content posts:", JSON.stringify(posts.rows, null, 2));

  const scheduled = await pool.query(`
    SELECT sp.id, sp.content_id, sp.account_id, sp.execute_at, sp.state, sp.error_code, sp.provider_post_id, sp.created_at, sa.platform, sa.name as account_name 
    FROM scheduled_posts sp 
    JOIN social_accounts sa ON sa.id = sp.account_id 
    WHERE sp.workspace_id = $1 
    ORDER BY sp.created_at DESC LIMIT 20
  `, [wid]);
  console.log("scheduled_posts:", JSON.stringify(scheduled.rows, null, 2));

  const visualConcepts = await pool.query("SELECT * FROM document_visual_concepts WHERE workspace_id = $1 ORDER BY created_at DESC LIMIT 5", [wid]);
  console.log("document_visual_concepts:", JSON.stringify(visualConcepts.rows, null, 2));

  await pool.end();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
