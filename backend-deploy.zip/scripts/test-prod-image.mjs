async function testProdImage() {
  const prodUrl = "https://api.hidustansocialnetwork.in/api/v1/storage/local/download?bucket=contentos-media&key=workspaces%2F4386cbf8-47bf-41fe-a925-0549bced08f2%2Fgenerated_asset%2F1d98333b-9078-478f-8a89-c52d9d861092%2Fvisual_flux.jpg&expires=1796461577869&sig=f55ada785dd6ec93630fd081e93a74833f59d7e96a306a517083a06daa4f8c08";
  try {
    const res = await fetch(prodUrl);
    console.log('Production URL fetch status:', res.status, 'Content-Type:', res.headers.get('content-type'), 'Length:', res.headers.get('content-length'));
  } catch (e) {
    console.error('Error:', e);
  }
}

testProdImage();
