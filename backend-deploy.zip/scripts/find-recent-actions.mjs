import process from "node:process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (typeof process.loadEnvFile === "function") {
  process.loadEnvFile(path.resolve(__dirname, "../.env"));
}

const { pool } = await import("../dist-api/db.js");

async function main() {
  const r = await pool.query("SELECT id, workspace_id, concept_title, status, scheduled_at, dispatched_at, post_result FROM document_visual_concepts WHERE concept_title ILIKE '%Global Financial%' OR concept_title ILIKE '%Daily Profit%'");
  console.log("document_visual_concepts:", JSON.stringify(r.rows, null, 2));

  const notifs = await pool.query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10");
  console.log("recent notifications:", JSON.stringify(notifs.rows, null, 2));

  const sched = await pool.query("SELECT sp.*, sa.platform FROM scheduled_posts sp JOIN social_accounts sa ON sa.id = sp.account_id ORDER BY sp.created_at DESC LIMIT 10");
  console.log("recent scheduled_posts:", JSON.stringify(sched.rows, null, 2));

  await pool.end();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
