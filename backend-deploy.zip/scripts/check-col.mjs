import { pool } from '../server/db.ts';

async function main() {
  const r = await pool.query(`
    SELECT column_name, data_type, udt_name 
    FROM information_schema.columns 
    WHERE table_name = 'document_visual_concepts' AND column_name = 'target_channels'
  `);
  console.log(r.rows);
  process.exit(0);
}
main();
