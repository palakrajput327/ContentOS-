async function testDirect() {
  const r = await fetch('https://tmpfiles.org/dl/wOARJuojSQnB/test.png');
  console.log('Status:', r.status, 'Content-Type:', r.headers.get('content-type'), 'Length:', r.headers.get('content-length'));
}
testDirect();
