import { pool } from '../server/db.ts';

async function main() {
  try {
    const wsId = '4386cbf8-47bf-41fe-a925-0549bced08f2';
    const accs = await pool.query(
      `SELECT id, platform, name, state FROM social_accounts WHERE workspace_id = $1`,
      [wsId]
    );
    console.log('Connected accounts for Palak:', JSON.stringify(accs.rows, null, 2));
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
