async function testDl() {
  const r = await fetch('https://d.uguu.se/OaoCpxfs.png');
  console.log('Status:', r.status, 'Type:', r.headers.get('content-type'), 'Length:', r.headers.get('content-length'));
}
testDl();
