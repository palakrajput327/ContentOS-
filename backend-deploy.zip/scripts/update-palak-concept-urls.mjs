import { pool } from '../server/db.ts';

async function main() {
  try {
    const wsId = '4386cbf8-47bf-41fe-a925-0549bced08f2';
    const r = await pool.query(
      `UPDATE document_visual_concepts
       SET image_url = REPLACE(image_url, 'http://localhost:3001', 'https://api.hidustansocialnetwork.in'),
           raw_image_url = REPLACE(raw_image_url, 'http://localhost:3001', 'https://api.hidustansocialnetwork.in')
       WHERE workspace_id = $1 AND (image_url LIKE 'http://localhost:3001%' OR raw_image_url LIKE 'http://localhost:3001%')`,
      [wsId]
    );
    console.log(`Updated ${r.rowCount} concepts for Palak to use canonical public domain.`);
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
