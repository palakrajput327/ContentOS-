import process from "node:process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (typeof process.loadEnvFile === "function") {
  process.loadEnvFile(path.resolve(__dirname, "../.env"));
}

const { pool } = await import("../dist-api/db.js");

async function main() {
  const notifs = await pool.query(`
    SELECT n.*, w.name as workspace_name
    FROM notifications n
    LEFT JOIN workspaces w ON w.id = n.workspace_id
    WHERE n.title ILIKE '%Smart Execution%' 
       OR n.title ILIKE '%Daily Profit%'
       OR n.title ILIKE '%Global Financial%'
       OR n.message ILIKE '%Smart Execution%'
       OR n.message ILIKE '%Daily Profit%'
       OR n.message ILIKE '%Global Financial%'
  `);
  console.log("Matching notifications count:", notifs.rows.length);
  console.log("Matching notifications:", JSON.stringify(notifs.rows, null, 2));

  await pool.end();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
