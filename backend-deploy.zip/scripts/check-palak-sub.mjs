import { pool } from '../server/db.ts';

async function main() {
  try {
    const wsId = '4386cbf8-47bf-41fe-a925-0549bced08f2';
    const sub = await pool.query(
      `SELECT * FROM workspace_subscriptions WHERE workspace_id = $1`,
      [wsId]
    );
    console.log('Subscription for Palak:', JSON.stringify(sub.rows, null, 2));

    const todayUsage = await pool.query(
      `SELECT count(*)::int as today_posts
       FROM scheduled_posts
       WHERE workspace_id = $1 AND created_at >= CURRENT_DATE`,
      [wsId]
    );
    console.log('Today posts created:', todayUsage.rows);

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
