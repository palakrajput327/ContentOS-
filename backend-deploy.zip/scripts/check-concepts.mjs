import process from "node:process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (typeof process.loadEnvFile === "function") {
  process.loadEnvFile(path.resolve(__dirname, "../.env"));
}

const { pool } = await import("../dist-api/db.js");

async function main() {
  const wid = "4386cbf8-47bf-41fe-a925-0549bced08f2";

  const concepts = await pool.query(`
    SELECT id, concept_title, status, scheduled_at, dispatched_at, target_channels, post_result, content_id 
    FROM document_visual_concepts 
    WHERE workspace_id = $1 
    ORDER BY updated_at DESC LIMIT 6
  `, [wid]);
  console.log("concepts:", JSON.stringify(concepts.rows, null, 2));

  const notifs = await pool.query(`
    SELECT * FROM notifications 
    WHERE workspace_id = $1 
    ORDER BY created_at DESC LIMIT 6
  `, [wid]);
  console.log("notifs:", JSON.stringify(notifs.rows, null, 2));

  const pub = await pool.query(`
    SELECT pp.*, sp.account_id, sa.platform, sa.name 
    FROM published_posts pp 
    JOIN scheduled_posts sp ON sp.id = pp.scheduled_post_id 
    JOIN social_accounts sa ON sa.id = sp.account_id 
    WHERE pp.workspace_id = $1 
    ORDER BY pp.published_at DESC LIMIT 10
  `, [wid]);
  console.log("published_posts:", JSON.stringify(pub.rows, null, 2));

  await pool.end();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
