async function testProdKey() {
  const url = "https://api.hidustansocialnetwork.in/api/v1/storage/local/download?bucket=contentos-media&key=workspaces%2F4386cbf8-47bf-41fe-a925-0549bced08f2%2Fgenerated_asset%2F743910c0-8353-436b-bec4-82e72e46265b%2Fvisual_flux.jpg&expires=1796451251209&sig=05b79a3a0a086e5f801a9ddf9fa040ecaf5418ffee5b4579f32f0fcd73c5611c";
  const r = await fetch(url);
  console.log('Status of concept 743910c0:', r.status);
}
testProdKey();
