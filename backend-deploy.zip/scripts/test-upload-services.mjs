import fs from 'node:fs';

async function testServices() {
  const dummyBuffer = Buffer.from('RIFF$    WEBPVP8  \x00\x00\x00/ \x00\x000\x00\x00', 'binary'); // minimal test buffer or tiny 1x1 png
  const png1px = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');

  // Test 1: tmpfiles.org
  try {
    const form1 = new FormData();
    form1.append('file', new Blob([png1px], { type: 'image/png' }), 'test.png');
    const r1 = await fetch('https://tmpfiles.org/api/v1/upload', { method: 'POST', body: form1 });
    const j1 = await r1.json();
    console.log('tmpfiles.org:', r1.status, j1?.data?.url);
    // tmpfiles returns https://tmpfiles.org/123/test.png, direct is https://tmpfiles.org/dl/123/test.png
    if (j1?.data?.url) {
      const direct = j1.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
      console.log('tmpfiles.org direct:', direct);
    }
  } catch (e) {
    console.log('tmpfiles.org err:', e.message);
  }

  // Test 2: 0x0.st
  try {
    const form2 = new FormData();
    form2.append('file', new Blob([png1px], { type: 'image/png' }), 'test.png');
    const r2 = await fetch('https://0x0.st', { method: 'POST', body: form2 });
    const text2 = await r2.text();
    console.log('0x0.st:', r2.status, text2.trim());
  } catch (e) {
    console.log('0x0.st err:', e.message);
  }

  // Test 3: freeimage.host
  try {
    const form3 = new FormData();
    form3.append('key', '6d207e02198a847e53c0a42212a4390f');
    form3.append('action', 'upload');
    form3.append('source', png1px.toString('base64'));
    form3.append('format', 'json');
    const r3 = await fetch('https://freeimage.host/api/1/upload', { method: 'POST', body: form3 });
    const j3 = await r3.json();
    console.log('freeimage.host:', r3.status, j3?.image?.url);
  } catch (e) {
    console.log('freeimage.host err:', e.message);
  }
}

testServices();
