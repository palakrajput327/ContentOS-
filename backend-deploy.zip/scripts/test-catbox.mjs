async function testCatbox() {
  try {
    const res = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/122.0.0.0' }
    });
    console.log('Catbox GET/POST status:', res.status);
  } catch (e) {
    console.error('Catbox error:', e);
  }
}

testCatbox();
