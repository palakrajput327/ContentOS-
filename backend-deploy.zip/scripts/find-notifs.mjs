import { pool } from '../server/db.ts';

async function main() {
  try {
    const notifs = await pool.query(
      `SELECT n.*, w.name as workspace_name
       FROM notifications n
       LEFT JOIN workspaces w ON w.id = n.workspace_id
       WHERE n.title ILIKE '%Published%'
       ORDER BY n.created_at DESC
       LIMIT 10`
    );
    console.log('Notifications:', JSON.stringify(notifs.rows, null, 2));
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
