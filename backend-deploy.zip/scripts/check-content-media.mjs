import { pool } from '../server/db.ts';

async function main() {
  try {
    const r = await pool.query(
      `SELECT c.id, c.title, c.status, c.variants, c.image_asset_id
       FROM content c
       WHERE c.id IN ('390bc8b3-b907-46fb-8178-1e2b75ccd1ae', 'b943aba9-4dd1-47fa-8d30-221db51642d7', '98eeec25-b9cb-4fc0-89e7-4be5d74d001c')`
    );
    console.log('Content details:', JSON.stringify(r.rows, null, 2));

    const spAll = await pool.query(
      `SELECT sp.id, sp.content_id, sp.state, sp.error_code, sp.provider_post_id, sa.platform
       FROM scheduled_posts sp
       JOIN social_accounts sa ON sa.id = sp.account_id
       WHERE sp.content_id IN ('390bc8b3-b907-46fb-8178-1e2b75ccd1ae', 'b943aba9-4dd1-47fa-8d30-221db51642d7', '98eeec25-b9cb-4fc0-89e7-4be5d74d001c')`
    );
    console.log('All scheduled posts for these 3 contents:', JSON.stringify(spAll.rows, null, 2));

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
