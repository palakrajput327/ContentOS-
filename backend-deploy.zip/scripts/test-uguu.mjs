async function testUguu() {
  const png1px = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
  try {
    const form = new FormData();
    form.append('files[]', new Blob([png1px], { type: 'image/png' }), 'test.png');
    const res = await fetch('https://uguu.se/upload.php', {
      method: 'POST',
      body: form,
      headers: { 'User-Agent': 'curl/8.4.0' }
    });
    console.log('Uguu status:', res.status, await res.text());
  } catch (e) {
    console.log('Uguu error:', e.message);
  }
}

testUguu();
