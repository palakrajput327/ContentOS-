import fs from 'node:fs';

const file = 'server/documents/visual-concepts.service.ts';
let code = fs.readFileSync(file, 'utf8').replace(/\r\n/g, '\n');

const oldLine = `await pool.query("UPDATE document_visual_concepts SET status=CASE WHEN $1 THEN 'DISPATCHED' ELSE status END,dispatched_at=CASE WHEN $1 THEN now() ELSE dispatched_at END,target_channels=$2,post_result=$3::jsonb WHERE id=$4 AND workspace_id=$5",[success,JSON.stringify(channels),JSON.stringify(results),opts.conceptId,opts.workspaceId]);`;
const newLine = `await pool.query("UPDATE document_visual_concepts SET status=CASE WHEN $1 THEN 'DISPATCHED' ELSE status END,dispatched_at=CASE WHEN $1 THEN now() ELSE dispatched_at END,target_channels=$2,post_result=$3::jsonb WHERE id=$4 AND workspace_id=$5",[success,channels,JSON.stringify(results),opts.conceptId,opts.workspaceId]);`;

if (!code.includes(oldLine)) {
  console.error("Could not find line 704 in visual-concepts.service.ts");
  process.exit(1);
}

code = code.replace(oldLine, newLine);
fs.writeFileSync(file, code);
console.log("Successfully fixed target_channels in visual-concepts.service.ts!");
