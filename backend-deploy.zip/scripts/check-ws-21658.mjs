import process from "node:process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (typeof process.loadEnvFile === "function") {
  process.loadEnvFile(path.resolve(__dirname, "../.env"));
}

const { pool } = await import("../dist-api/db.js");

async function main() {
  const ws = await pool.query("SELECT * FROM workspaces WHERE id = '21658c69-7587-41d8-9e2e-7ba5bacac212'");
  console.log("workspace 21658c69:", ws.rows[0]);

  const members = await pool.query("SELECT m.*, u.email, u.name FROM workspace_members m JOIN users u ON u.id = m.user_id WHERE m.workspace_id = '21658c69-7587-41d8-9e2e-7ba5bacac212'");
  console.log("members:", members.rows);

  const accs = await pool.query("SELECT id, platform, name, state FROM social_accounts WHERE workspace_id = '21658c69-7587-41d8-9e2e-7ba5bacac212'");
  console.log("accounts:", accs.rows);

  const pub = await pool.query("SELECT pp.*, sp.account_id, sa.platform, sa.name, c.title FROM published_posts pp JOIN scheduled_posts sp ON sp.id = pp.scheduled_post_id JOIN social_accounts sa ON sa.id = sp.account_id JOIN content c ON c.id = sp.content_id WHERE pp.workspace_id = '21658c69-7587-41d8-9e2e-7ba5bacac212' ORDER BY pp.published_at DESC LIMIT 10");
  console.log("published_posts:", pub.rows);

  await pool.end();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
