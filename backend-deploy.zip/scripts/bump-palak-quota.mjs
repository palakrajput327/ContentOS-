import { pool } from '../server/db.ts';

async function main() {
  try {
    const wsId = '4386cbf8-47bf-41fe-a925-0549bced08f2';
    await pool.query(
      `UPDATE workspace_subscriptions
       SET custom_daily_limit = 100, updated_at = NOW()
       WHERE workspace_id = $1`,
      [wsId]
    );
    console.log('Successfully set custom_daily_limit to 100 for Palak workspace');
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
