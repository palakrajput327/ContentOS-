import { pool } from '../server/db.ts';

async function main() {
  try {
    const concepts = await pool.query(
      `SELECT dvc.id, dvc.workspace_id, dvc.document_id, dvc.concept_title, dvc.status, dvc.scheduled_at, dvc.dispatched_at, dvc.target_channels, dvc.post_result, dvc.content_id, dvc.image_url, w.name as workspace_name
       FROM document_visual_concepts dvc
       LEFT JOIN workspaces w ON w.id = dvc.workspace_id
       WHERE dvc.concept_title ILIKE '%Global Financial Infrastructure%'
          OR dvc.concept_title ILIKE '%Daily Profit Distribution%'
          OR dvc.concept_title ILIKE '%Smart Execution Engine%'
       ORDER BY dvc.updated_at DESC`
    );
    console.log('Concepts found:', JSON.stringify(concepts.rows, null, 2));

    if (concepts.rows.length > 0) {
      const contentIds = concepts.rows.map(r => r.content_id).filter(Boolean);
      if (contentIds.length > 0) {
        const posts = await pool.query(
          `SELECT sp.*, sa.platform, sa.account_name
           FROM scheduled_posts sp
           JOIN social_accounts sa ON sa.id = sp.account_id
           WHERE sp.content_id = ANY($1::uuid[])`,
          [contentIds]
        );
        console.log('Scheduled posts for these concepts:', JSON.stringify(posts.rows, null, 2));
      }
    }

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
