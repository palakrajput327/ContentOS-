import process from "node:process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (typeof process.loadEnvFile === "function") {
  process.loadEnvFile(path.resolve(__dirname, "../.env"));
}

const { pool } = await import("../dist-api/db.js");

async function main() {
  const wid = "4386cbf8-47bf-41fe-a925-0549bced08f2";
  const rows = await pool.query(`
    SELECT id, concept_title, status, scheduled_at, dispatched_at, target_channels, post_result, content_id, created_at, updated_at 
    FROM document_visual_concepts 
    WHERE workspace_id = $1 
    ORDER BY scheduled_at ASC NULLS LAST
  `, [wid]);
  console.log("Total concepts:", rows.rows.length);
  console.log("Concepts:", JSON.stringify(rows.rows, null, 2));

  await pool.end();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
