import process from "node:process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (typeof process.loadEnvFile === "function") {
  process.loadEnvFile(path.resolve(__dirname, "../.env"));
}

const { pool } = await import("../dist-api/db.js");

async function main() {
  const posts = await pool.query(`
    SELECT c.id, c.title, c.platforms, c.status, c.created_at, c.workspace_id, w.name as workspace_name
    FROM content c
    JOIN workspaces w ON w.id = c.workspace_id
    WHERE c.title ILIKE '%Global Financial Infrastructure%'
       OR c.title ILIKE '%Daily Profit Distribution%'
       OR c.title ILIKE '%Smart Execution Engine%'
  `);
  console.log("Matching content items:", JSON.stringify(posts.rows, null, 2));

  for (const post of posts.rows) {
    const sp = await pool.query(`
      SELECT sp.*, sa.platform, sa.name as account_name
      FROM scheduled_posts sp
      LEFT JOIN social_accounts sa ON sa.id = sp.account_id
      WHERE sp.content_id = $1
    `, [post.id]);
    console.log(`scheduled_posts for ${post.title}:`, JSON.stringify(sp.rows, null, 2));

    const pub = await pool.query(`
      SELECT * FROM published_posts WHERE scheduled_post_id IN (
        SELECT id FROM scheduled_posts WHERE content_id = $1
      )
    `, [post.id]);
    console.log(`published_posts for ${post.title}:`, JSON.stringify(pub.rows, null, 2));
  }

  await pool.end();
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
