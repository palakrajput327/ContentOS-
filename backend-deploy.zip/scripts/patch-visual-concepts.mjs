import fs from 'node:fs';

const file = 'server/documents/visual-concepts.service.ts';
let code = fs.readFileSync(file, 'utf8').replace(/\r\n/g, '\n');

const oldVariants = `    // Build platform-specific caption variants
    const variants: Record<string, any> = {};
    for (const ch of channels) {
      const customVariant = opts.variants?.[ch]?.caption;
      const platformCaption = customVariant || formatCaptionForPlatform(caption, ch);
      variants[ch] = {
        caption: platformCaption,
        mediaAssetId: row.asset_id,
        mediaUrl: row.image_url,
      };
    }`;

const newVariants = `    // Build platform-specific caption variants with canonical public media URL
    const publicStorageBase = (process.env.STORAGE_PUBLIC_URL || process.env.PUBLIC_URL || "https://api.hidustansocialnetwork.in").replace(/\\/+$/, "");
    let canonicalImageUrl = row.image_url;
    if (canonicalImageUrl && /^https?:\\/\\/(localhost|127\\.0\\.0\\.1)(:\\d+)?/i.test(canonicalImageUrl)) {
      canonicalImageUrl = canonicalImageUrl.replace(/^https?:\\/\\/(localhost|127\\.0\\.0\\.1)(:\\d+)?/i, publicStorageBase);
    }

    const variants: Record<string, any> = {};
    for (const ch of channels) {
      const customVariant = opts.variants?.[ch]?.caption;
      const platformCaption = customVariant || formatCaptionForPlatform(caption, ch);
      variants[ch] = {
        caption: platformCaption,
        mediaAssetId: row.asset_id,
        mediaUrl: canonicalImageUrl,
      };
    }`;

if (!code.includes(oldVariants)) {
  console.error("Could not find oldVariants in server/documents/visual-concepts.service.ts");
  process.exit(1);
}

code = code.replace(oldVariants, newVariants);

// Also pass manualPublish: true to publishContentNow
const oldPublish = `try { results.push({platform:ch,...await publishContentNow(opts.workspaceId,opts.userId,prepared,account.id)}); }`;
const newPublish = `try { results.push({platform:ch,...await publishContentNow(opts.workspaceId,opts.userId,prepared,account.id,true)}); }`;

if (code.includes(oldPublish)) {
  code = code.replace(oldPublish, newPublish);
} else {
  console.error("Could not find oldPublish in server/documents/visual-concepts.service.ts");
  process.exit(1);
}

fs.writeFileSync(file, code);
console.log("Successfully patched server/documents/visual-concepts.service.ts!");
