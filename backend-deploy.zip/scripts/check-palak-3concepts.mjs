import { pool } from '../server/db.ts';

async function main() {
  try {
    const wsId = '4386cbf8-47bf-41fe-a925-0549bced08f2';
    const c = await pool.query(
      `SELECT id, concept_title, status, scheduled_at, dispatched_at, target_channels, post_result, content_id
       FROM document_visual_concepts
       WHERE workspace_id = $1 AND id IN ('2751c173-675b-4544-86c7-791b9fbbaba6', '0ce7cdeb-cf45-4d2b-8233-ce0caa222e0e', '6dff7e95-3314-4e7d-aefb-96bc2681f9b2')`,
      [wsId]
    );
    console.log('Concepts:', JSON.stringify(c.rows, null, 2));

    const contentIds = c.rows.map(r => r.content_id).filter(Boolean);
    if (contentIds.length > 0) {
      const posts = await pool.query(
        `SELECT sp.*, sa.platform
         FROM scheduled_posts sp
         JOIN social_accounts sa ON sa.id = sp.account_id
         WHERE sp.content_id = ANY($1::uuid[])`,
        [contentIds]
      );
      console.log('Scheduled posts:', JSON.stringify(posts.rows, null, 2));

      const pub = await pool.query(
        `SELECT * FROM published_posts WHERE content_id = ANY($1::uuid[])`,
        [contentIds]
      );
      console.log('Published posts:', JSON.stringify(pub.rows, null, 2));
    }

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
