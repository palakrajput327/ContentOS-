async function testProductionUrl() {
  try {
    const res = await fetch('https://api.hidustansocialnetwork.in/api/v1/storage/local/download?test=1');
    console.log('Production storage download status:', res.status);
  } catch (e) {
    console.error('Error reaching api.hidustansocialnetwork.in:', e.message);
  }
}

testProductionUrl();
