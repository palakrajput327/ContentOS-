import { pool } from '../server/db.ts';

async function main() {
  try {
    const wsId = '4386cbf8-47bf-41fe-a925-0549bced08f2';
    
    // Check all concepts for this workspace
    const concepts = await pool.query(
      `SELECT id, concept_title, status, scheduled_at, dispatched_at, target_channels, post_result, updated_at
       FROM document_visual_concepts
       WHERE workspace_id = $1
       ORDER BY updated_at DESC
       LIMIT 10`,
      [wsId]
    );
    console.log('--- CONCEPTS ---');
    console.log(JSON.stringify(concepts.rows, null, 2));

    const posts = await pool.query(
      `SELECT *
       FROM scheduled_posts
       WHERE workspace_id = $1
       ORDER BY created_at DESC
       LIMIT 10`,
      [wsId]
    );
    console.log('--- SCHEDULED POSTS ---');
    console.log(JSON.stringify(posts.rows, null, 2));

    const published = await pool.query(
      `SELECT *
       FROM published_posts
       WHERE workspace_id = $1
       ORDER BY created_at DESC
       LIMIT 10`,
      [wsId]
    );
    console.log('--- PUBLISHED POSTS ---');
    console.log(JSON.stringify(published.rows, null, 2));

    const accounts = await pool.query(
      `SELECT id, platform, account_name, is_connected, status
       FROM social_accounts
       WHERE workspace_id = $1`,
      [wsId]
    );
    console.log('--- SOCIAL ACCOUNTS ---');
    console.log(JSON.stringify(accounts.rows, null, 2));

    const notifs = await pool.query(
      `SELECT id, type, title, message, created_at
       FROM notifications
       WHERE workspace_id = $1
       ORDER BY created_at DESC
       LIMIT 10`,
      [wsId]
    );
    console.log('--- NOTIFICATIONS ---');
    console.log(JSON.stringify(notifs.rows, null, 2));

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
