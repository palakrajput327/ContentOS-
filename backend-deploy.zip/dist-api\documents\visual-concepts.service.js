import { pool } from "../db.js";
import { getLLMProvider } from "../ai/llm.service.js";
import { ClipdropService } from "../clipdrop/clipdrop.service.js";
import { randomUUID } from "node:crypto";
import { z } from "zod";
export class VisualConceptsService {
    /**
     * Retrieves existing visual concepts or generates fresh ones from PDF knowledge
     */
    async getOrGenerateConcepts(documentId, workspaceId) {
        // 1. Ensure concepts for this active document are generated if not yet in database
        const docConcepts = await pool.query(`SELECT COUNT(*)::int as count FROM document_visual_concepts WHERE document_id = $1 AND workspace_id = $2`, [documentId, workspaceId]);
        if ((docConcepts.rows[0]?.count || 0) === 0) {
            await this.regenerateConcepts(documentId, workspaceId);
        }
        // 2. Fetch all undispatched concepts across the workspace queue (accumulates across PDF uploads)
        const existing = await pool.query(`SELECT dvc.id, dvc.document_id, dvc.concept_title, dvc.source_page, dvc.source_excerpt, dvc.prompt,
              dvc.asset_id, dvc.image_url, dvc.raw_image_url, dvc.raw_asset_id, dvc.status, dvc.scheduled_at, dvc.dispatched_at, dvc.target_channels, dvc.created_at,
              COALESCE(d.original_filename, 'Document') as document_name
       FROM document_visual_concepts dvc
       LEFT JOIN documents d ON d.id = dvc.document_id
       WHERE dvc.workspace_id = $1 AND (dvc.status IS NULL OR dvc.status != 'DISPATCHED')
       ORDER BY dvc.created_at ASC, dvc.source_page ASC`, [workspaceId]);
        const dispatchedRes = await pool.query(`SELECT COUNT(*)::int as count FROM document_visual_concepts
       WHERE workspace_id = $1 AND status = 'DISPATCHED'`, [workspaceId]);
        const dispatchedCount = dispatchedRes.rows[0]?.count || 0;
        if (existing.rowCount && existing.rowCount > 0) {
            const concepts = existing.rows.map((r) => ({
                id: r.id,
                documentId: r.document_id,
                documentName: r.document_name,
                conceptTitle: r.concept_title,
                sourcePage: r.source_page || 1,
                sourceExcerpt: r.source_excerpt || "",
                prompt: r.prompt,
                assetId: r.asset_id,
                imageUrl: r.image_url,
                rawImageUrl: r.raw_image_url || r.image_url,
                rawAssetId: r.raw_asset_id || r.asset_id,
                status: r.status || "PENDING",
                scheduledAt: r.scheduled_at ? new Date(r.scheduled_at).toISOString() : null,
                dispatchedAt: r.dispatched_at ? new Date(r.dispatched_at).toISOString() : null,
                targetChannels: r.target_channels || ["linkedin"],
                createdAt: r.created_at,
            }));
            return {
                concepts,
                count: concepts.length,
                notice: `Dispatch queue active: ${concepts.length} queued visual concept${concepts.length > 1 ? "s" : ""} scheduled across your document batch.`,
            };
        }
        if (dispatchedCount > 0) {
            return {
                concepts: [],
                count: 0,
                allDispatched: true,
                notice: "All visual posts from this PDF have been successfully published! Please upload a new PDF document to generate and schedule your next content batch.",
            };
        }
        return {
            concepts: [],
            count: 0,
            allDispatched: false,
            notice: "Document content is currently being analyzed and extracted by AI. Visual concepts will appear automatically.",
        };
    }
    /**
     * Forces fresh regeneration of visual concepts directly from document content using Gemini
     */
    async regenerateConcepts(documentId, workspaceId) {
        // 1. Fetch document knowledge
        const kRes = await pool.query(`SELECT id, knowledge_key, value, source_excerpt, page_start
       FROM document_knowledge
       WHERE document_id = $1 AND workspace_id = $2
       ORDER BY page_start ASC, created_at ASC`, [documentId, workspaceId]);
        let contentSummary = "";
        if (kRes.rowCount && kRes.rowCount > 0) {
            contentSummary = kRes.rows
                .slice(0, 40)
                .map((r, idx) => `Concept #${idx + 1} [Page ${r.page_start || 1}]: "${r.knowledge_key}"\nDetail: ${typeof r.value === "string" ? r.value : JSON.stringify(r.value)}\nQuote: "${(r.source_excerpt || "").slice(0, 250)}"`)
                .join("\n\n");
        }
        else {
            // Fallback to document pages if knowledge extraction hasn't completed yet
            const pagesRes = await pool.query(`SELECT page_number, clean_text FROM document_pages WHERE document_id = $1 AND workspace_id = $2 ORDER BY page_number ASC LIMIT 25`, [documentId, workspaceId]);
            if (pagesRes.rowCount && pagesRes.rowCount > 0) {
                contentSummary = pagesRes.rows
                    .map((p) => `Page ${p.page_number}:\n${p.clean_text.slice(0, 800)}`)
                    .join("\n\n");
            }
        }
        if (!contentSummary.trim()) {
            return {
                concepts: [],
                count: 0,
                allDispatched: false,
                notice: "Document content is currently being analyzed and extracted by AI. Visual concepts will appear automatically.",
            };
        }
        // 2. Fetch document title
        const docRes = await pool.query(`SELECT original_filename FROM documents WHERE id = $1 AND workspace_id = $2`, [documentId, workspaceId]);
        const docName = docRes.rows[0]?.original_filename || "Business Document";
        // 3. Ask Gemini to extract genuine visual concepts using FLUX-native Comma-Separated Tag Engine (T5-XXL optimized)
        const provider = getLLMProvider();
        const systemPrompt = `You are an elite Commercial Advertising Creative Director & FLUX.1 Visual Prompt Architect.
Your mission: Analyze the uploaded business PDF / pitch deck / whitepaper, deeply understand its REAL business model, products, figures, and offerings, and create 100% ACCURATE, highly relevant commercial advertising visuals.

STRICT ACCURACY RULES (ZERO HARDCODED ANIMALS OR IRRELEVANT TROPES):
1. NO RANDOM ANIMALS: Do NOT add bulls, lions, eagles, or animals unless the PDF explicitly features an animal in its brand or text.
2. 100% CONTENT-ACCURATE VISUALS:
   - If the page is about Global Infrastructure / Tech: Visualize futuristic global financial network, glowing fiber-optic data streams, clean algorithmic digital systems.
   - If the page is about Daily ROI / Profit Distribution: Visualize executive trading command desk with clean rising candlestick charts, glowing upward growth vectors, and the exact return figures.
   - If the page is about Packages / Capital Entry: Visualize sleek digital asset vault, cryptocurrency allocation interface, and BEP-20 verification badges.
   - If the page is about Referral / Network Income: Visualize interconnected professional leadership network nodes and collaborative digital links.
   - If the page is about Royalty Club / Leadership Rewards: Visualize prestigious executive achievement awards, golden milestone trophies, and global turnover revenue streams.
   - If the page is about Security / Compliance: Visualize high-tech cryptographic security shield, verified blockchain ledger blocks, and auditable protocol interfaces.

CRITICAL TEXT & SPELLING ACCURACY RULES (PREVENTS GIBBERISH & TYPOS):
- FLUX achieves 100% spelling accuracy ONLY when text is kept to 1 to 3 SHORT words maximum (e.g. "TRADEORBIT", "1% - 3% DAILY", "SMART FINTECH", "10% DIRECT", "5X ACCELERATOR", "ROYALTY CLUB").
- NEVER prompt long sentences or multi-line paragraphs into the image (this causes garbled typos).
- Explicitly instruct FLUX: 'The text "[EXACT_SHORT_PHRASE]" is displayed in sharp, clean, bold metallic lettering with 100% correct spelling, zero typos, and clean legible typography.'
- Explicit negative constraints in every prompt: 'no misspelled words, no gibberish letters, no random floating characters, no duplicate text, clean sharp typography, 8k commercial photography'.

Scale dynamically across the document: Extract 6 to 14 distinct concepts covering all key pages and sections.
Return JSON with "concepts" array.`;
        let rawList = [];
        try {
            const ConceptItemSchema = z.union([
                z.string(),
                z.object({
                    conceptTitle: z.string().optional(),
                    title: z.string().optional(),
                    name: z.string().optional(),
                    concept: z.string().optional(),
                    sourcePage: z.any().optional(),
                    sourceExcerpt: z.string().optional(),
                    prompt: z.string().optional(),
                    description: z.string().optional(),
                }).passthrough(),
            ]);
            const res = await provider.generateStructured({
                messages: [
                    { role: "system", content: systemPrompt },
                    {
                        role: "user",
                        content: `Document: "${docName}"\n\nComprehensive Extracted Content from PDF:\n${contentSummary}\n\nExtract all distinct core business concepts across this document as accurate commercial FLUX prompts:\nReturn JSON with "concepts" array.`,
                    },
                ],
                schema: z.object({
                    concepts: z.array(ConceptItemSchema),
                }).passthrough(),
                schemaName: "DocumentVisualConceptsExtraction",
                maxTokens: 4096,
            });
            const data = res.data;
            let rawArr = [];
            if (Array.isArray(data)) {
                rawArr = data;
            }
            else if (Array.isArray(data?.concepts)) {
                rawArr = data.concepts;
            }
            else if (Array.isArray(data?.items)) {
                rawArr = data.items;
            }
            else if (data && typeof data === "object") {
                const firstArr = Object.values(data).find(Array.isArray);
                if (firstArr)
                    rawArr = firstArr;
            }
            // Map dynamically with real unique titles from Gemini!
            rawList = rawArr.map((item, idx) => {
                let title = "";
                let prompt = "";
                let page = idx + 1;
                let excerpt = "";
                if (typeof item === "string") {
                    prompt = item.trim();
                    const firstTag = prompt.split(",")[0]?.trim() || `Core Pillar #${idx + 1}`;
                    title = firstTag.slice(0, 60).replace(/^(a|an|the)\s+/i, "");
                    title = title.charAt(0).toUpperCase() + title.slice(1);
                }
                else if (item && typeof item === "object") {
                    title = (item.conceptTitle || item.title || item.name || item.concept || "").trim();
                    prompt = (item.prompt || item.description || "").trim();
                    if (!title && prompt) {
                        const firstTag = prompt.split(",")[0]?.trim() || `Core Pillar #${idx + 1}`;
                        title = firstTag.slice(0, 60).replace(/^(a|an|the)\s+/i, "");
                        title = title.charAt(0).toUpperCase() + title.slice(1);
                    }
                    page = typeof item.sourcePage === "number" ? item.sourcePage : (idx + 1);
                    excerpt = (item.sourceExcerpt || "").trim();
                }
                return {
                    title: title || `Core Pillar #${idx + 1}`,
                    sourcePage: page,
                    sourceExcerpt: excerpt,
                    prompt,
                };
            }).filter((c) => c.prompt && c.prompt.length > 15);
            console.log(`[VisualConceptsService] Successfully extracted ${rawList.length} dynamic concepts with unique titles via Gemini 2.5 Flash`);
        }
        catch (err) {
            console.warn("[VisualConceptsService] LLM structured extraction warning:", err?.message || err);
        }
        // High-quality dynamic fallback: If LLM failed or returned empty, formulate 4 completely distinct FLUX tag prompts
        if (!rawList || rawList.length === 0) {
            const distinctCategories = [
                {
                    key: "Global Financial Infrastructure & Platform Vision",
                    prompt: `Commercial financial technology advertising creative for ${docName.replace(/\.pdf$/i, '')}, sharp bold metallic typography "GLOBAL FINTECH" at top with 100% correct spelling, luminous fiber-optic digital world globe with golden and cobalt blue data streams connecting international financial hubs, sleek obsidian marble background, volumetric studio lighting, clean legible typography, no typos, no gibberish, 8k commercial photography`,
                },
                {
                    key: "Daily Profit Distribution & Earning Engine",
                    prompt: `Commercial luxury financial advertising creative for ${docName.replace(/\.pdf$/i, '')}, clear bold 3D golden numbers "1% - 3% DAILY" with exact spelling, executive trading workstation with rising financial candlestick charts under warm amber and deep navy ambient lighting, sleek marble desk, sharp typography, zero typos, no random letters, 8k resolution, cinematic commercial photography`,
                },
                {
                    key: "Smart Execution Engine & Risk Control",
                    prompt: `High-tech commercial fintech creative for ${docName.replace(/\.pdf$/i, '')}, sharp 3D metallic typography "SMART EXECUTION" with 100% correct spelling, futuristic algorithmic trading node with clean holographic risk management analytics, glowing cyan and gold light circuits, clean sharp focus, no spelling mistakes, 8k resolution`,
                },
                {
                    key: "Multi-Tier Accelerator & Leadership Rewards",
                    prompt: `Commercial financial rewards creative for ${docName.replace(/\.pdf$/i, '')}, sharp 3D metallic typography "5X ACCELERATOR" with exact spelling, ascending luxury golden achievement tiers with floating metallic black and gold VIP cards, volumetric light beams, luxury dark aesthetic, zero typos, 8k commercial photography`,
                },
            ];
            if (kRes.rowCount && kRes.rowCount > 0) {
                rawList = kRes.rows.slice(0, 10).map((r, idx) => {
                    const cat = distinctCategories[idx % distinctCategories.length];
                    return {
                        title: r.knowledge_key || cat.key,
                        sourcePage: r.page_start || idx + 1,
                        sourceExcerpt: (r.source_excerpt || "").slice(0, 150),
                        prompt: cat.prompt,
                    };
                });
            }
            else {
                rawList = distinctCategories.map((cat, idx) => ({
                    title: cat.key,
                    sourcePage: idx + 1,
                    sourceExcerpt: "",
                    prompt: cat.prompt,
                }));
            }
        }
        // 4. Clean up old concepts for this document and insert newly generated ones
        await pool.query(`DELETE FROM document_visual_concepts WHERE document_id = $1 AND workspace_id = $2`, [documentId, workspaceId]);
        const savedConcepts = [];
        for (const item of rawList) {
            const id = randomUUID();
            const title = (item.title || "Business Concept").trim().slice(0, 120);
            const page = typeof item.sourcePage === "number" ? item.sourcePage : 1;
            const excerpt = (item.sourceExcerpt || "").trim().slice(0, 400);
            const prompt = (item.prompt || "").trim();
            if (!prompt || prompt.length < 15)
                continue;
            await pool.query(`INSERT INTO document_visual_concepts (id, document_id, workspace_id, concept_title, source_page, source_excerpt, prompt)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`, [id, documentId, workspaceId, title, page, excerpt, prompt]);
            savedConcepts.push({
                id,
                documentId,
                conceptTitle: title,
                sourcePage: page,
                sourceExcerpt: excerpt,
                prompt,
                createdAt: new Date().toISOString(),
            });
        }
        const count = savedConcepts.length;
        return {
            concepts: savedConcepts,
            count,
            notice: `Extracted ${count} high-impact visual concepts from this document. (If you require additional unique visual angles, consider uploading documents with further business details or expanded sections).`,
        };
    }
    /**
     * Generates a 1024x1024 visual via FLUX.1 for a specific concept
     */
    async generateConceptVisual(opts) {
        const row = (await pool.query(`SELECT id, concept_title, prompt FROM document_visual_concepts WHERE id = $1 AND workspace_id = $2 AND document_id = $3`, [opts.conceptId, opts.workspaceId, opts.documentId])).rows[0];
        if (!row) {
            throw new Error("Visual concept not found in this document.");
        }
        const promptToUse = (opts.customPrompt && opts.customPrompt.trim().length > 10)
            ? opts.customPrompt.trim()
            : row.prompt;
        const { BrandIdentityService } = await import("./brand-identity.service.js");
        const brandService = new BrandIdentityService();
        const isForce = opts.force ?? true;
        const clipdropService = new ClipdropService();
        const result = await clipdropService.generateImage({
            workspaceId: opts.workspaceId,
            userId: opts.userId,
            prompt: promptToUse + "\nDo not draw company logos, domains or URLs. Approved branding is added afterward.",
            enableOverlay: false,
            headline: row.concept_title,
            aspectRatio: "1:1",
            engine: "flux",
            bypassCache: isForce,
            idempotencyKey: isForce ? `concept-visual:${opts.conceptId}:${Date.now()}` : undefined,
        });
        // Store raw AI generated artwork separately!
        let finalAssetId = result.assetId;
        let finalImageUrl = result.url;
        const rawAssetId = result.assetId;
        const rawImageUrl = result.url;
        const branded = await brandService.brandGeneratedImage({ documentId: opts.documentId, workspaceId: opts.workspaceId, userId: opts.userId, assetId: result.assetId, url: result.url });
        finalAssetId = branded.assetId;
        finalImageUrl = branded.url;
        // Save both final (branded) poster and raw (pure AI artwork) to concept row
        await pool.query(`UPDATE document_visual_concepts
       SET asset_id = $1, image_url = $2, raw_asset_id = $3, raw_image_url = $4, prompt = $5, updated_at = NOW()
       WHERE id = $6`, [finalAssetId, finalImageUrl, rawAssetId, rawImageUrl, promptToUse, opts.conceptId]);
        return {
            conceptId: opts.conceptId,
            assetId: finalAssetId,
            imageUrl: finalImageUrl,
        };
    }
    /**
     * Dispatches a concept to social channels, records publication, and marks as DISPATCHED
     */
    async dispatchConcept(opts) {
        const row = (await pool.query(`SELECT id, concept_title, prompt, source_excerpt, asset_id, image_url 
         FROM document_visual_concepts 
         WHERE id = $1 AND workspace_id = $2 AND document_id = $3`, [opts.conceptId, opts.workspaceId, opts.documentId])).rows[0];
        if (!row) {
            throw new Error("Visual concept not found in this document.");
        }
        // Auto-Safety Guarantee: If no visual was generated manually, auto-generate via FLUX before dispatching!
        if (!row.image_url || !row.asset_id) {
            console.log(`[VisualConcepts] Concept ${opts.conceptId} has no visual yet. Auto-synthesizing FLUX visual before dispatch...`);
            try {
                const genRes = await this.generateConceptVisual({
                    documentId: opts.documentId,
                    conceptId: opts.conceptId,
                    workspaceId: opts.workspaceId,
                    userId: opts.userId,
                });
                row.image_url = genRes.imageUrl;
                row.asset_id = genRes.assetId;
                console.log(`[VisualConcepts] Auto visual synthesis complete: ${genRes.imageUrl}`);
            }
            catch (genErr) {
                throw genErr;
            }
        }
        const { BrandIdentityService } = await import("./brand-identity.service.js");
        const brandService = new BrandIdentityService();
        try {
            const brand = await brandService.getOrCreateBrandIdentity(opts.documentId, opts.workspaceId);
            if (brandService.isBrandReady(brand)) {
                try {
                    const branded = await brandService.recomposeConceptPoster(opts);
                    row.image_url = branded.imageUrl;
                    row.asset_id = branded.assetId;
                }
                catch {
                    await brandService.warnOptionalBrand(opts.documentId, opts.workspaceId);
                }
            }
            else {
                await brandService.warnOptionalBrand(opts.documentId, opts.workspaceId);
            }
        }
        catch {
            await brandService.warnOptionalBrand(opts.documentId, opts.workspaceId);
        }
        const dispatchedAt = new Date().toISOString();
        const channels = Array.isArray(opts.channels) && opts.channels.length > 0 ? opts.channels : ["linkedin"];
        // Fetch connected accounts for this workspace
        const accountsRes = await pool.query(`SELECT id, platform, name FROM social_accounts WHERE workspace_id = $1 AND state = 'CONNECTED'`, [opts.workspaceId]);
        const connectedAccounts = accountsRes.rows;
        // Build platform captions
        const caption = row.source_excerpt || `Strategic Architecture: ${row.concept_title}\n\nIn modern enterprise governance, foundational clarity and rigorous verification drive sustainable advantage.`;
        const variants = {};
        for (const ch of channels) {
            variants[ch] = {
                caption,
                mediaAssetId: row.asset_id,
                mediaUrl: row.image_url,
            };
        }
        // Create content item with status = 'SCHEDULED' so claim() can claim it
        const contentId = randomUUID();
        await pool.query(`INSERT INTO content (id, workspace_id, created_by, updated_by, title, body, variants, platforms, status, image_asset_id, created_at, updated_at)
       VALUES ($1, $2, $3, $3, $4, $5, $6, $7, 'SCHEDULED', $8, NOW(), NOW())`, [
            contentId,
            opts.workspaceId,
            opts.userId,
            row.concept_title,
            caption,
            JSON.stringify(variants),
            JSON.stringify(channels),
            row.asset_id || null,
        ]);
        // Create content_versions record
        await pool.query(`INSERT INTO content_versions (id, workspace_id, content_id, version, snapshot, created_by, created_at)
       VALUES ($1, $2, $3, 1, $4, $5, NOW())`, [
            randomUUID(),
            opts.workspaceId,
            contentId,
            JSON.stringify({ title: row.concept_title, body: caption, variants, platforms: channels }),
            opts.userId,
        ]);
        // Create scheduled_posts for each connected matching account and publish live!
        const publishResults = [];
        let publishedCount = 0;
        for (const ch of channels) {
            const matchedAccount = connectedAccounts.find((a) => a.platform.toLowerCase() === ch.toLowerCase());
            if (matchedAccount) {
                const spId = randomUUID();
                await pool.query(`INSERT INTO scheduled_posts (id, workspace_id, content_id, account_id, content_version, execute_at, timezone, state, created_at)
           VALUES ($1, $2, $3, $4, 1, NOW() - INTERVAL '5 seconds', 'UTC', 'ENQUEUED', NOW())`, [spId, opts.workspaceId, contentId, matchedAccount.id]);
                try {
                    const { executePublishRecord } = await import("../publishing.js");
                    console.log(`[VisualConcepts] Auto-publishing live to ${matchedAccount.platform} (${matchedAccount.name})...`);
                    const res = await executePublishRecord(spId, { now: new Date(Date.now() + 10000), attemptsMade: 0, maxAttempts: 3 });
                    publishResults.push({ platform: matchedAccount.platform, result: res });
                    if (res.success)
                        publishedCount++;
                }
                catch (pubErr) {
                    console.warn(`[VisualConcepts] Direct publish error for ${matchedAccount.platform}:`, pubErr?.message || pubErr);
                    publishResults.push({ platform: matchedAccount.platform, error: pubErr?.message || String(pubErr) });
                }
            }
        }
        // Mark concept as DISPATCHED in database with live publish results
        await pool.query(`UPDATE document_visual_concepts
       SET status = 'DISPATCHED', dispatched_at = NOW(), target_channels = $1::jsonb, post_result = $2::jsonb
       WHERE id = $3`, [JSON.stringify(channels), JSON.stringify(publishResults), opts.conceptId]);
        // Finalize content status
        await pool.query(`UPDATE content SET status = 'PUBLISHED', updated_at = NOW() WHERE id = $1`, [contentId]);
        return {
            success: true,
            conceptId: opts.conceptId,
            dispatchedAt,
            publishedCount,
        };
    }
    /**
     * Syncs and persists automated dispatch slots to the database
     */
    async syncSchedule(opts) {
        const { documentId, workspaceId, slots } = opts;
        const safeChannels = Array.isArray(opts.channels) && opts.channels.length > 0 ? opts.channels : ["linkedin"];
        if (!slots || slots.length === 0) {
            return { success: false, scheduledCount: 0, slots: [] };
        }
        const sortedSlots = [...slots].sort((a, b) => a.time.localeCompare(b.time));
        const concepts = (await pool.query(`SELECT id, concept_title, source_page, prompt
         FROM document_visual_concepts
         WHERE document_id = $1 AND workspace_id = $2 AND (status IS NULL OR status != 'DISPATCHED')
         ORDER BY source_page ASC, created_at ASC`, [documentId, workspaceId])).rows;
        let timezone = opts.timezone;
        if (!timezone) {
            const wsRes = await pool.query(`SELECT timezone FROM workspaces WHERE id = $1`, [workspaceId]);
            timezone = wsRes.rows[0]?.timezone || 'Asia/Kolkata';
        }
        const now = new Date();
        const nowParts = new Intl.DateTimeFormat('en-US', {
            timeZone: timezone,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
        }).formatToParts(now);
        const curHourStr = nowParts.find((p) => p.type === 'hour')?.value || '00';
        const curMinStr = nowParts.find((p) => p.type === 'minute')?.value || '00';
        const currentHour = parseInt(curHourStr === '24' ? '0' : curHourStr, 10);
        const currentMin = parseInt(curMinStr, 10);
        let dayOffset = 0;
        let slotIdx = sortedSlots.findIndex((s) => {
            const [h, m] = s.time.split(':').map(Number);
            return h > currentHour || (h === currentHour && m > currentMin);
        });
        if (slotIdx === -1) {
            dayOffset = 1;
            slotIdx = 0;
        }
        function parseDateInTz(y, mo, da, h, mi, tz) {
            const isoLocal = `${y}-${mo}-${da}T${String(h).padStart(2, '0')}:${String(mi).padStart(2, '0')}:00`;
            try {
                const d = new Date(isoLocal + 'Z');
                const targetStr = d.toLocaleString('en-US', { timeZone: tz });
                const targetDate = new Date(targetStr);
                const utcStr = d.toLocaleString('en-US', { timeZone: 'UTC' });
                const utcDate = new Date(utcStr);
                const offsetMs = targetDate.getTime() - utcDate.getTime();
                return new Date(d.getTime() - offsetMs);
            }
            catch {
                return new Date(isoLocal + 'Z');
            }
        }
        let count = 0;
        for (const c of concepts) {
            const slot = sortedSlots[slotIdx];
            const checkBase = new Date(now.getTime() + dayOffset * 24 * 60 * 60 * 1000);
            const parts = new Intl.DateTimeFormat('en-US', {
                timeZone: timezone,
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
            }).formatToParts(checkBase);
            const y = parts.find((p) => p.type === 'year')?.value || '2026';
            const mo = parts.find((p) => p.type === 'month')?.value || '01';
            const da = parts.find((p) => p.type === 'day')?.value || '01';
            const [sh, sm] = slot.time.split(':').map(Number);
            const targetUtcDate = parseDateInTz(y, mo, da, sh, sm, timezone || 'Asia/Kolkata');
            await pool.query(`UPDATE document_visual_concepts
         SET scheduled_at = $1, target_channels = $2::jsonb, status = 'PENDING', updated_at = NOW()
         WHERE id = $3`, [targetUtcDate.toISOString(), JSON.stringify(safeChannels), c.id]);
            count++;
            slotIdx++;
            if (slotIdx >= sortedSlots.length) {
                slotIdx = 0;
                dayOffset++;
            }
        }
        console.log(`[VisualConcepts] Successfully synced schedule for ${count} visual concepts on document ${documentId}`);
        return {
            success: true,
            scheduledCount: count,
            slots: sortedSlots,
        };
    }
}
